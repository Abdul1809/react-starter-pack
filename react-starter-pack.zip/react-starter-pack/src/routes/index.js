import React from 'react';
import { Route, IndexRoute } from 'react-router';
import App from '../components/App';
import Hello from '../components/Hello';
import World from '../components/world';
export default(
  <Route path="/" component={App} >
    <IndexRoute component={Hello} />
    <Route path="world" component={World} />
  </Route>
);
